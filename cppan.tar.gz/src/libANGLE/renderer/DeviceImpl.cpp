//
// Copyright (c) 2015 The ANGLE Project Authors. All rights reserved.
// Use of this source code is governed by a BSD-style license that can be
// found in the LICENSE file.
//

// DeviceImpl.cpp: Implementation methods of egl::Device

#include "libANGLE/renderer/DeviceImpl.h"

namespace rx
{

DeviceImpl::DeviceImpl()
{
}

DeviceImpl::~DeviceImpl()
{
}

}
